package com.pedidosApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidosAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
